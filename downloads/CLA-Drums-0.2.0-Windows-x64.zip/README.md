# CLA Drums — C++ / JUCE

Efeito VST3 Windows x64, versão 0.2.0, em C++17 com JUCE 7.0.12 fixado no commit `4f43011b96eb0636104cb3e433894cda98243626`.

## Controles e processamento

A interface contém entrada, **cinco módulos centrais** e saída. Cada botão de módulo alterna entre **verde, azul e vermelho**; ON desativa individualmente o módulo. Os faders e botões estão vinculados aos mesmos parâmetros usados pelos presets e pela automação da DAW.

- **Input Sensitivity:** trim de -10 a +10 dB. Acima de 0 dB, introduz progressivamente uma curva de saturação harmônica tanh, antes do compressor e do gate. Ambos detectam o sinal após o ganho de entrada, respondendo ao aumento do fader.
- **LED de sensibilidade:** mede o pico após o trim, antes da saturação. Verde abaixo de -18 dBFS; amarelo entre -18 e -3 dBFS; vermelho a partir de -3 dBFS. O indicador de clip do medidor fica retido a partir de 0 dBFS até RESET CLIP. Esses limiares são escolhas de implementação.
- **Output:** trim final de -10 a +10 dB após os efeitos e o roteamento Direct.
- **Ø Phase:** inverte a polaridade dos dois canais.
- **Bass:** três curvas por peça; grave profundo em shelf e duas curvas bell de corpo/limpeza. Frequências por peça em `Source/DrumVoicing.h`.
- **Treble:** uma curva bell de ataque/presença e dois shelves de brilho/ar, com frequências por peça.
- **Compress:** verde Push (2:1, ataque 25 ms), azul Spank (5:1, ataque 15 ms), vermelho Wall (20:1, ataque 1 ms). O fader ajusta o limiar e a liberação depende da peça. Detector estéreo ligado para manter a imagem central.
- **Reverb:** três estruturas de ambiência: reflexões iniciais com campo curto, campo longo com realimentação cruzada e chamber com três estágios all-pass de difusão. Tamanho, damping, predelay e nomes dependem da peça; na caixa: Tight / Large / Chamber.
- **Gate:** disponível em Kick, Snare, Toms, OH e Room. Verde Fast, azul Natural e vermelho Gated 80s. Os tempos de release variam por peça; Gated 80s acrescenta hold de 180 ms e aplica o gate depois da ambiência, cortando também a cauda do reverb.
- **Delay no Cowbell:** o mesmo quinto fader, botão de cor e ON são reconectados aos parâmetros de delay. O gate não processa Cowbell. Verde 1/4, azul 1/8, vermelho 1/8 pontuada. O delay não processa os demais modos, mesmo que um parâmetro antigo esteja ativado.
- **Sincronismo:** lê o BPM da DAW; sem transporte válido usa 120 BPM. Faixa suportada: 20–400 BPM. Feedback do delay: 30%.
- **DIRECT / Top Switch:** compara o áudio seco, com trim de entrada, polaridade e trim de saída, ao processado. Mantém os efeitos calculando e ajusta o ganho da ramificação seca pelo RMS do processado. Compensação limitada a ±18 dB, com congelamento em silêncio e transição suavizada de 20 ms. Pode precisar de aproximadamente um segundo para estabilizar; não é medição LUFS nem normalização de pico. BYPASS é separado e passa o áudio original em ganho unitário.

26 presets: Init; 4 Kick; 5 Snare; 3 Toms; 3 OH; 4 Room; 2 Drum Bus; 4 Cowbell. Incluem entrada com drive, Gated 80s e três subdivisões de delay. A seleção atualiza níveis, cores, ativações, fonte, fase, bypass e Direct. Edições manuais também são salvas na sessão. O nome identifica o último preset carregado.

Os parâmetros Gate e Delay mantêm valores independentes no estado da sessão, embora compartilhem um único controle físico. As cores de gate e delay da versão 0.1 tinham outro significado; esta versão aplica as três opções solicitadas. A restauração de estados antigos inicializa Direct como desligado.

## Compilar em Windows x64

Instale Visual Studio 2022 com Desktop development with C++, Windows SDK, CMake 3.22+ e Git. No PowerShell:

```powershell
./scripts/build-windows.ps1
```

O script baixa o JUCE fixado, compila Release x64, executa testes e gera `dist/CLA-Drums-Windows-x64.zip`. Copie a pasta inteira `CLA Drums.vst3` para `C:\Program Files\Common Files\VST3` e reescaneie a DAW. É um efeito para pistas de áudio, não um instrumento que produz amostras de bateria.

O workflow `.github/workflows/windows.yml` contém o mesmo build/testes em Windows. Não foi enviado nem executado remotamente nesta sessão.

## Desenvolvimento no ambiente preparado

Use o checkout existente. Cada tarefa na nuvem já é isolada; não crie outro worktree sem solicitação.

```sh
./scripts/build-cloud.sh linux   # compila e testa a versão nativa
./scripts/build-cloud.sh windows # gera o VST3 Windows x64 por compilação cruzada
```

`scripts/setup-cloud.sh` reproduz as ferramentas e dependências no espaço de trabalho sem sudo. Para outros ambientes Linux, instale as dependências JUCE de desenvolvimento (ALSA, X11/Xext/Xinerama/Xrandr/Xcursor e FreeType), depois use CMake normalmente. `JUCE_SOURCE_DIR` aceita um checkout local; sem ele, CMake baixa a versão fixada. `DRUMS_BUILD_TESTS=OFF` omite os testes.

Os testes cobrem presets, estado editado, GUI, troca Gate/Delay, cores, harmônicos de entrada, saída, três subdivisões em múltiplos BPMs, exclusividade por peça, envelopes do gate, corte de cauda, curvas de EQ/ambiência, Direct, silêncio, mono, fase, bypass e blocos de tamanho variável. `build-linux7/DrumsTests Assets/editor-preview.png` exporta a interface.

## Limites da validação

O DSP é uma implementação autoral dos comportamentos solicitados. Não reproduz algoritmos proprietários nem comprova a assinatura sonora de Chris Lord-Alge. As frequências, tempos e curvas estão documentados e podem ser ajustados. O painel usa o cabeçalho gerado com controles interativos; ainda não é um clone visual idêntico.

O VST3 Windows é compilado com MinGW/JUCE 7 e tem arquitetura PE x86-64 e exports VST3 verificados. Os testes de áudio e GUI são executados no Linux. Falta carregar e ouvir este binário numa DAW Windows. O manifesto opcional moduleinfo.json é omitido na compilação cruzada.

Observe a licença JUCE aplicável à distribuição. Os nomes e a referência visual não indicam associação com o fabricante original.
