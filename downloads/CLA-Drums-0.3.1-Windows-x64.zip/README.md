# CLA Drums — C++ / JUCE

Efeito VST3 Windows x64, versão 0.3.1, em C++17 com JUCE 7.0.12 fixado no commit `4f43011b96eb0636104cb3e433894cda98243626`.

## Correção de estabilidade 0.3.1

A versão 0.3.0 continha um laço extra de realimentação em CLUB/Large: a saída wet retornava à entrada do reverb com ganho 0,22. O ganho agregado dos combs podia superar a unidade e oscilar mesmo após o áudio terminar. Esse laço foi removido. Não use as versões 0.2/0.3 para processamento com reverb; substitua o plugin pela 0.3.1 e reinicie a DAW.

As três estruturas agora usam engines independentes com ganhos normalizados, remoção de DC da saída wet e crossfade de 20 ms entre modos. A mudança de modo não expõe buffers inativos nem corta a cauda de forma abrupta. O ganho da ambiência foi recalibrado, portanto o wet pode soar mais baixo que nas versões defeituosas. Os IDs dos parâmetros e o formato de estado foram mantidos.

Entradas NaN/Inf são descartadas antes dos filtros, e o headroom de entrada é limitado a ±16 (aproximadamente +24 dBFS) para conter dados fora do domínio suportado. Índices de modos e parâmetros inválidos são limitados antes de acessar tabelas. Os caminhos de bypass interno e da DAW continuam avançando o DSP.

A suíte `audio_stability` inclui o cenário informado, 26 presets com automação, 114 combinações prolongadas de modo/canal/taxa e casos de bypass/dados inválidos. Consulte `VALIDATION-0.3.1.md` para os resultados e limites.

## Controles e processamento

A interface contém entrada, **cinco módulos centrais** e saída. Os botões amarelos com seta alternam as três opções de cada módulo; a seleção aparece em **verde, azul ou vermelho no visor superior**, como na referência. Clique direito na seta ativa/desativa o módulo. Os faders e botões estão vinculados aos mesmos parâmetros usados pelos presets e pela automação da DAW.

- **Input Sensitivity:** trim de -10 a +10 dB. Acima de 0 dB, introduz progressivamente uma curva de saturação harmônica tanh, antes do compressor e do gate. Ambos detectam o sinal após o ganho de entrada, respondendo ao aumento do fader.
- **LED de sensibilidade:** mede o pico após o trim, antes da saturação. Verde abaixo de -18 dBFS; amarelo entre -18 e -3 dBFS; vermelho a partir de -3 dBFS. O indicador de clip do medidor fica retido a partir de 0 dBFS até clicar no respectivo medidor. Esses limiares são escolhas de implementação.
- **Output:** trim final de -10 a +10 dB após os efeitos e o roteamento Direct.
- **Ø Phase:** inverte a polaridade dos dois canais.
- **Bass:** três curvas por peça; grave profundo em shelf e duas curvas bell de corpo/limpeza. Frequências por peça em `Source/DrumVoicing.h`.
- **Treble:** uma curva bell de ataque/presença e dois shelves de brilho/ar, com frequências por peça.
- **Compress:** verde Push (2:1, ataque 25 ms), azul Spank (5:1, ataque 15 ms), vermelho Wall (20:1, ataque 1 ms). O fader ajusta o limiar e a liberação depende da peça. Detector estéreo ligado para manter a imagem central.
- **Reverb:** três estruturas de ambiência: reflexões iniciais com campo curto, campo longo com realimentação interna limitada e chamber com três estágios all-pass de difusão. Tamanho, damping, predelay e nomes dependem da peça; na caixa: Tight / Large / Chamber.
- **Gate:** disponível em Kick, Snare, Toms, OH e Room. Verde Fast, azul Natural e vermelho Gated 80s. Os tempos de release variam por peça; Gated 80s acrescenta hold de 180 ms e aplica o gate depois da ambiência, cortando também a cauda do reverb.
- **Delay no Cowbell:** o mesmo quinto fader, seta e estado de ativação são reconectados aos parâmetros de delay. O gate não processa Cowbell. Verde 1/4, azul 1/8, vermelho 1/8 pontuada. O delay não processa os demais modos, mesmo que um parâmetro antigo esteja ativado.
- **Sincronismo:** lê o BPM da DAW; sem transporte válido usa 120 BPM. Faixa suportada: 20–400 BPM. Feedback do delay: 30%, com interpolação e transição de 30 ms ao mudar tempo/subdivisão.
- **DIRECT / Top Switch (clique no título da coleção):** compara o áudio seco, com trim de entrada, polaridade e trim de saída, ao processado. Mantém os efeitos calculando e ajusta o ganho da ramificação seca pelo RMS do processado. Compensação limitada a ±18 dB, com congelamento em silêncio e transição suavizada de 20 ms. Pode precisar de aproximadamente um segundo para estabilizar; não é medição LUFS nem normalização de pico. BYPASS é separado, acessível por clique direito no título ou pelo menu ?, e passa o áudio original em ganho unitário. O DSP continua avançando durante bypass para evitar ecos congelados ao reativar.

26 presets: Init; 4 Kick; 5 Snare; 3 Toms; 3 OH; 4 Room; 2 Drum Bus; 4 Cowbell. Incluem entrada com drive, Gated 80s e três subdivisões de delay. A seleção atualiza níveis, cores, ativações, fonte, fase, bypass e Direct. Edições manuais também são salvas na sessão. O nome identifica o último preset carregado.

Os parâmetros Gate e Delay mantêm valores independentes no estado da sessão, embora compartilhem um único controle físico. As cores de gate e delay da versão 0.1 tinham outro significado; esta versão aplica as três opções solicitadas. A restauração de estados antigos inicializa Direct como desligado.


## Interface da versão 0.3

- Proporção de referência 924 × 586, redimensionável de 80% a 200%, mantendo o alinhamento dos controles e a proporção.
- Sete faders móveis com material metálico, relevo, brilho e sombra; valores aparecem somente durante interação, sem caixas numéricas permanentes.
- Seletor giratório de seis posições; os nomes das peças também são clicáveis.
- Visor de três linhas por módulo; somente o modo ativo fica colorido. STUDIO/CLUB/HALL são os rótulos da pele para as três voicings de ambiência. No Cowbell, o quinto visor e fader tornam-se Delay.
- Barra superior: presets, desfazer/refazer edições da interface, comparação A/B de configurações e Load/Save de arquivos `.cladrums`. O histórico e as memórias A/B pertencem à janela aberta; o estado corrente continua salvo na sessão da DAW.
- Botão Ø no canto inferior esquerdo. Clique no medidor para zerar seu clip; o pequeno dial L/R alterna apenas a exibição dos canais de entrada, sem alterar áudio.
- `Assets/editor-preview.png` mostra a interface renderizada; `Assets/editor-cowbell-2x.png` mostra a variante Cowbell em 2×. São capturas reais do editor JUCE, não mockups.

## Compilar em Windows x64

Instale Visual Studio 2022 com Desktop development with C++, Windows SDK, CMake 3.22+ e Git. No PowerShell:

```powershell
./scripts/build-windows.ps1
```

O script baixa o JUCE fixado, compila Release x64, executa testes e gera `dist/CLA-Drums-Windows-x64.zip`. Copie a pasta inteira `CLA Drums.vst3` para `C:\Program Files\Common Files\VST3` e reescaneie a DAW. É um efeito para pistas de áudio, não um instrumento que produz amostras de bateria.

O workflow `.github/workflows/windows.yml` contém o mesmo build/testes em Windows. Não foi enviado nem executado remotamente nesta sessão.

## Desenvolvimento no ambiente preparado

Use o checkout existente. Cada tarefa na nuvem já é isolada; não crie outro worktree sem solicitação.

```sh
./scripts/build-cloud.sh linux   # compila e testa a versão nativa
./scripts/build-cloud.sh windows # gera o VST3 Windows x64 por compilação cruzada
```

`scripts/setup-cloud.sh` reproduz as ferramentas e dependências no espaço de trabalho sem sudo. Para outros ambientes Linux, instale as dependências JUCE de desenvolvimento (ALSA, X11/Xext/Xinerama/Xrandr/Xcursor e FreeType), depois use CMake normalmente. `JUCE_SOURCE_DIR` aceita um checkout local; sem ele, CMake baixa a versão fixada. `DRUMS_BUILD_TESTS=OFF` omite os testes.

Os testes `processor_and_presets` e `audio_stability` cobrem presets, estado editado, GUI, troca Gate/Delay, cores, harmônicos de entrada, saída, três subdivisões em múltiplos BPMs, exclusividade por peça, envelopes do gate, corte de cauda, curvas de EQ/ambiência, Direct, silêncio, mono, fase, bypass e blocos de tamanho variável. `build-linux7/DrumsTests Assets/editor-preview.png` exporta a interface.

## Limites da validação

O DSP é uma implementação autoral dos comportamentos solicitados. Não reproduz algoritmos proprietários nem comprova a assinatura sonora de Chris Lord-Alge. As frequências, tempos e curvas estão documentados e podem ser ajustados. A versão 0.3 redesenha o painel inteiro conforme a referência, com base fototexturizada, moldura e divisórias metálicas em relevo, faders de prata com sprites transparentes e sombra, seletor giratório, botões amarelos, visor de modos e medidores nos encaixes do painel. Os assets foram recriados a partir da imagem; identidade pixel a pixel com o original não foi estabelecida.

O VST3 Windows é compilado com MinGW/JUCE 7 e tem arquitetura PE x86-64 e exports VST3 verificados. Os testes de áudio e GUI são executados no Linux. Falta carregar e ouvir este binário numa DAW Windows. O manifesto opcional moduleinfo.json é omitido na compilação cruzada.

Observe a licença JUCE aplicável à distribuição. Os nomes e a referência visual não indicam associação com o fabricante original.

## Diagnóstico com sanitizadores

Com GCC/Clang nativo, configure `-DDRUMS_SANITIZE_PROCESSOR=ON`, compile os alvos `DrumsTests` e `DrumsStabilityTests` e execute CTest. A opção instrumenta o código do processador, editor e testes com AddressSanitizer e UndefinedBehaviorSanitizer; não instrumenta todos os módulos de terceiros. Os builds de distribuição usam a opção desligada.
